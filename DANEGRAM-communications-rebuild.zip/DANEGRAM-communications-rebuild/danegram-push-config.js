// Set this to the VAPID public key generated for DANEGRAM push notifications.
// Never place the VAPID PRIVATE key or a Supabase secret/service key in this file.
window.DG_VAPID_PUBLIC_KEY = '';
