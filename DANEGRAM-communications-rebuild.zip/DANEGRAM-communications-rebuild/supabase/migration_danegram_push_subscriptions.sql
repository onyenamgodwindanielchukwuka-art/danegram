-- DANEGRAM browser push endpoints. Run once in the Supabase SQL Editor.
create table if not exists public.danegram_push_subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  endpoint text not null unique,
  p256dh text not null,
  auth text not null,
  user_agent text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists danegram_push_subscriptions_user_id_idx
  on public.danegram_push_subscriptions(user_id);

alter table public.danegram_push_subscriptions enable row level security;
grant select, insert, update, delete on public.danegram_push_subscriptions to authenticated;

drop policy if exists "Members manage their own push subscriptions" on public.danegram_push_subscriptions;
create policy "Members manage their own push subscriptions"
  on public.danegram_push_subscriptions
  for all to authenticated
  using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);
