/* DANEGRAM service worker: background message/call notifications. */
const DG_CACHE = 'danegram-shell-v1';
self.addEventListener('install', event => { self.skipWaiting(); });
self.addEventListener('activate', event => { event.waitUntil(self.clients.claim()); });
self.addEventListener('push', event => {
  let data = {};
  try { data = event.data ? event.data.json() : {}; } catch { data = { body: event.data?.text?.() || 'You have a new DANEGRAM alert.' }; }
  const kind = data.kind || 'message';
  const title = data.title || (kind === 'call' ? 'Incoming DANEGRAM call' : 'New DANEGRAM message');
  const options = {
    body: data.body || (kind === 'call' ? 'Someone is calling you on DANEGRAM.' : 'You received a new message.'),
    icon: '/icons/danegram-192.png',
    badge: '/icons/danegram-192.png',
    tag: data.tag || `danegram-${kind}-${data.conversation_id || 'general'}`,
    renotify: kind === 'call',
    requireInteraction: kind === 'call',
    vibrate: kind === 'call' ? [500, 250, 500, 250, 700] : [120, 60, 120],
    data: { url: data.url || '/', conversation_id: data.conversation_id || null, call_id: data.call_id || null, kind }
  };
  event.waitUntil(self.registration.showNotification(title, options));
});
self.addEventListener('notificationclick', event => {
  event.notification.close();
  const d = event.notification.data || {};
  const url = d.kind === 'call' ? '/?openCall=' + encodeURIComponent(d.call_id || '') : '/?openConversation=' + encodeURIComponent(d.conversation_id || '');
  event.waitUntil((async () => {
    const windows = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    for (const client of windows) {
      if ('focus' in client) { await client.focus(); client.postMessage({ type: 'DANEGRAM_NOTIFICATION_OPEN', data: d }); return; }
    }
    if (self.clients.openWindow) await self.clients.openWindow(url);
  })());
});
self.addEventListener('notificationclose', event => {
  // No call is auto-declined when a notification is dismissed.
});
